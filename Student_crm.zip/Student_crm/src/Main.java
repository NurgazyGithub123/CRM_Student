import dao.StudentDao;
import model.Student;
import util.DaoContext;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        StudentDao studentDao = DaoContext.autowired("StudentDao", "singleton");
        Student student = new Student();


//        List<Student> listStudent = new ArrayList();
//        Student student = new Student("Nur", "Dyikanbaev", "nur@gmail.com", "1234567890", LocalDate.parse("1234-12-12"), LocalDateTime.now());
//        Student student2 = new Student("Nurik", "doe", "doe@gmail.ru", "1234567891", LocalDate.parse("1234-12-02"), LocalDateTime.now());
//        Student student3 = new Student("Narynbek", "Dyik", "naryn@gmail.com", "1234567892", LocalDate.parse("1234-12-03"), LocalDateTime.now());
//        Student student4 = new Student("John", "Dyik", "john@mail.com", "1234567893", LocalDate.parse("1234-12-11"), LocalDateTime.now());
//        Student student5 = new Student("Nurbek", "Dyik", "nurbek@gmail.com", "1234567894", LocalDate.parse("1234-12-08"), LocalDateTime.now());
//        Student student6 = new Student("Melis", "Dyik", "melis@gmail.com", "1234567895", LocalDate.parse("1234-12-13"), LocalDateTime.now());

//        listStudent.add(student);
//        listStudent.add(student3);
//        listStudent.add(student2);
//        listStudent.add(student4);
//        listStudent.add(student5);
//        studentDao.saveAll(listStudent);

            System.out.print(" Last:");
            student.setLastName(sc.nextLine());

            System.out.print(" First:");
            student.setFirstName(sc.nextLine());

            System.out.print(" Email:");
            student.setEmail(sc.nextLine());

            System.out.print(" Phone:");
            student.setPhoneNumber(sc.nextLine());

            System.out.print(" Dob:");
            student.setDob(LocalDate.parse(sc.nextLine()));

            studentDao.save(student);


    }
}
